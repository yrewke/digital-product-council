# Codex Council V2

Codex Council V2 is a separate, Codex-only council framework for bounded research and decision support. It preserves the older restaurant council systems and runs beside them instead of replacing them.

## What It Is

- Five permanent executive lenses: Contrarian, First-Principles Thinker, Expansionist, Outsider, and Executor.
- Service agents outside the five: Librarian, Evidence Auditor / Accountant, Devil's Advocate, and Chairman.
- One canonical memo file per executive per run.
- Central evidence memory and request deduplication.
- Permanent factual / numerical evidence veto for the Auditor.
- Mission-specific executive vetoes defined in each run charter.
- Resumable state machine, append-only event ledger, deterministic validation, and synthetic dry-run coverage through the same engine used by real runs.

## New System Root

`codex-council-v2/`

Repository-local Codex entry points:

- Skill: `.agents/skills/codex-council-v2/`
- Agents: `.codex/agents/codex-council-v2-*.toml`

## Commands

Initialize a real run scaffold:

```powershell
python codex-council-v2/scripts/codex_council_v2.py init-run --run-id 2026-06-17-example --title "Example bounded decision" --question "What bounded action should we choose?"
```

Run the synthetic framework test:

```powershell
python codex-council-v2/scripts/codex_council_v2.py synthetic-test
```

Run the test suite:

```powershell
python -m unittest discover -s codex-council-v2/tests -v
```

Validate a run:

```powershell
python codex-council-v2/scripts/codex_council_v2.py validate-run --run-dir codex-council-v2/runs/synthetic-fixture-001
```

Resume from the last valid stage:

```powershell
python codex-council-v2/scripts/codex_council_v2.py resume --run-dir codex-council-v2/runs/synthetic-fixture-001
```

Check status:

```powershell
python codex-council-v2/scripts/codex_council_v2.py status --run-dir codex-council-v2/runs/synthetic-fixture-001
```

## Real Run Pattern

The Codex skill orchestrates these engine operations: `init-run`, `validate-charter`, `open-evidence-requests`, `register-evidence-request`, `resolve-evidence-request`, `mark-evidence-ready`, `submit-memo`, `extract-claims`, `record-fact-check`, `validate-audit`, `create-anonymous-review-packets`, `record-peer-review`, `merge-review-events`, `record-author-response`, `record-veto`, `prepare-chairman-packet`, `record-first-synthesis`, `record-devils-advocate`, `record-provisional-verdict`, `open-post-chair-review`, `record-final-verdict`, `validate-run`, `resume`, and `complete-run`.

Python validates state, locks, cache reuse, review routing, audit resolution, veto scope, and old-system hashes. Codex supplies the reasoning text submitted into those commands.

Additional hardening commands:

```powershell
python codex-council-v2/scripts/codex_council_v2.py waive-peer-review --run-dir <run-dir> --assignment-id RA-0020 --reason "Reviewer failed after retry"
python codex-council-v2/scripts/codex_council_v2.py resolve-veto --run-dir <run-dir> --veto-id V-0001
```

## Release Status

`READY_FOR_BOUNDED_REAL_RUN`

The first real mission must still be treated as a controlled pilot. Live NotebookLM, web research, source import, login, account switching, paid research, and bulk crawling still require explicit approval.

## First Real Run Prompt

Use `$codex-council-v2` to initialize and run a new Codex-only council for `[decision question]`. Use `codex-council-v2/scripts/codex_council_v2.py` as the deterministic state engine, dispatch the V2 custom agents for reasoning, and stop before live NotebookLM or web research unless explicitly approved.
