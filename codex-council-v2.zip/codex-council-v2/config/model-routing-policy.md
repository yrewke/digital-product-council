# Model Routing Policy

Do not hardcode unavailable model names. The operator should inspect the active Codex environment before a real run and record available choices in the run charter.

## Economy Tier

Use for formatting, metadata, routing, anonymization, claim extraction, request deduplication, status updates, and schema validation.

## Standard Reasoning Tier

Use for ordinary executive memos, evidence synthesis, implementation analysis, and peer review.

## Frontier Reasoning Tier

Use only for difficult Contrarian or First-Principles analysis, major contradiction resolution, complex Chairman synthesis, and high-stakes final review.

## Manual Fallback

## Current Verification

`codex.cmd doctor` on 2026-06-17 reported Codex `0.131.0` with active model `gpt-5.5`. The local TOML agent profiles are available as separate role entry points, but this repository does not rely on unverified per-agent model keys.

## Tested Manual Fallback

The run charter records tier assignments. When per-agent routing cannot be enforced by local TOML, the `$codex-council-v2` operator uses explicit tier labels in dispatch prompts:

- Economy: run engine commands, packet creation, metadata, and validation.
- Standard: ordinary executive memos, peer review, and evidence synthesis.
- Frontier: Chairman synthesis, difficult Contrarian / First-Principles passes, and major contradiction resolution.

Do not spend frontier reasoning on mechanical file operations.
